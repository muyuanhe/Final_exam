import numpy as np
import math
import random
import matplotlib
import matplotlib.pyplot as plt
from functions import get_init_energy  #compute energies
from functions import energy_difference  #compute energy differences
from scipy.optimize import curve_fit
#import example
#example

#metropolis criterion
def metropolis(e,enew): # bool, returns true of false
	if(e>enew):
		return True
	else:
		if np.random.random() < math.exp((e-enew)):
			return True
		else:
			return False

N=50  #size of the lattice
nstep=5*1e5	#steps in the simulation(iterations)
printstep=1000	#steps between printing
nprint=int(nstep/printstep)
nrun=100 # 100 runs per simulation

### part a

t=np.zeros(nprint)
avm=np.zeros(nprint)
ave=np.zeros(nprint)
ave_square = np.zeros(nprint)
avm_square = np.zeros(nprint)
C_n = np.zeros(nprint) # Part d: C(n) is a list to store <m_taue * m_taue+n>, all entries before taue == 10000 is stored as 0

#np.random.seed(2)
#J = 0.1 # just change J outside. Another loop is too easy to make error
#J = 0.2
#J = 0.3
J = 0.4

b=0  #magnetic field.
pbc=True  #this flags whether to use PBCs

# already have lists ave and avm to store them based on time step, too many if based on n, basically the same thing.
# E_list = [] # update based on iternation number n
# for cell in np.arange(nrun):
#     E_list.append([]) # now E_list is a list of 100 run lists, each stores energy


# Set up the initial state "Board" named spins
for run in np.arange(nrun):
    counter = 0
    ran_L = []
    list_of_choice = [-1, 1]
    ran_L = random.choices(list_of_choice, weights = [1, 1],  k = N**2) # create a list of -1 and 1s, length is 50x50, 50% chance up and down
    spins = [[0 for _ in range(N)] for _ in range(N)]  # define the spins as all down
    m_taue = 0 # this m_tau_e is to stay 0 untill tau_e reaches 10000, otherwise all C(n)[step/printstep] should stay 0
    m = 0
    for i in np.arange(N):
        for j in np.arange(N):
            spins[i][j] = ran_L[counter]
            counter += 1
    # finish of initial state setup
    e = get_init_energy(spins, J, b, N, pbc)
    #E_list[run].append(e) # run based
    #print("initial energy", e)
    for step in np.arange(nstep):
        s1 = np.random.randint(0, N) # random flip row
        s2 = np.random.randint(0, N) # random flip column
        enew = e + energy_difference(s1, s2, spins, J, b, N, pbc)

        if (metropolis(e, enew)): # bool logic, if true, to flip or not to flip
            spins[s1][s2] = -spins[s1][s2]
            if spins[s1][s2] > 0: # update the spin
                m = m+2 # magnetization for spin up
            else:
                m = m-2 # for spin down
            e = enew # update the energy
            #E_list[run].append(e) # update the E list when e is confirmed to be updated
        if step == 1e4:
            m_taue = m
        if step % printstep == 0:
            t[int(step / printstep)] = step
            # every printstep, we want to print data
            avm[int(step / printstep)] += abs(m)
            ave[int(step / printstep)] += e
            ave_square[int(step/printstep)] += e**2
            avm_square[int(step/printstep)] += m**2
            C_n[int(step/printstep)] += m_taue * m


plt.plot(t/nrun,ave/nrun)
plt.xlabel('time')
plt.ylabel('<E>')
plt.title('average energy over time')
plt.show()

plt.plot(t/nrun,ave_square/nrun - (ave/nrun)**2)
plt.xlabel('time')
plt.ylabel('<E^2> - <E>^2')
plt.title('Flactuation(sigma)')
plt.show()

### part b and part c
# single exponential curve. <E> = ave/nrun, n = t/nrun
np.random.seed(4)

def exponFit(n,A1,B1,tau_e, fake_parameter): # single exponential fit
	return A1*np.exp(-n/tau_e) + B1

def biExponFit(n,A2,B2,m1,m2): # double exponential fit
	return A2*np.exp(-n/m1)+B2*np.exp(-n/m2)

def func_d(n, D, tau_c):
    return D*np.exp(-n/tau_c)

init_vals=[1,1, 1, 1]
fits,cov=curve_fit(exponFit,t/nrun,ave/nrun,p0=init_vals) # basically ave/nrun is y and t/nrun is x
print("epxonential paramter fits:")
print("(in the order of: A, B, tau_e)")
print(fits[:-1])
print("mean squared error:")
print(sum((ave/nrun-exponFit(nrun,*fits))**2)/len(t/nrun))
print(" ")

plt.scatter(t/nrun,ave/nrun)
plt.plot(t/nrun,exponFit(t/nrun,*fits))
plt.title("exponential fit")
plt.show()

# double exponential curve
init_vals=[1,1,1,1e6]
fits,cov=curve_fit(biExponFit,t/nrun,ave/nrun,p0=init_vals)
print("biexponential paramter fits:")
print("(in the order of: A, B, m1, m2)")
print(fits)
print("mean squared error")
print(sum((ave/nrun-biExponFit(t/nrun,*fits))**2)/len(t/nrun))
print(" ")

plt.scatter(t/nrun,ave/nrun)
plt.plot(t/nrun,biExponFit(t/nrun,*fits))
plt.title("biexponential fit")
plt.show()

print("The bi-exponential fit does not give a better fit because m2 goes to very large and therefore Bexp(-n/m2) goes to B, which is the same as single exponential fit")

### part d
tau_e = 1e4
# therefore in list avm, the m_te is stored at avm[tau_e/printstep]
t_backup = t
t = t[int(tau_e/printstep):]
C_n = C_n[int(tau_e/printstep):] # because prior C_n are all zero

init_vals=[100,100]
fits,cov=curve_fit(func_d,t/nrun,C_n/nrun,p0=init_vals) # basically ave/nrun is y and t/nrun is x
print("epxonential paramter fits:")
print("(in the order of: D, tau_c)")
print(fits)
print(" ")
plt.scatter(t/nrun,C_n/nrun)
plt.plot(t/nrun,func_d(t/nrun,*fits))
plt.xlabel("n")
plt.ylabel("C(n = <m_te * m_n+te>)")
plt.title("fit for C(n)")
plt.show()

### part e
plt.plot(t_backup/nrun, avm/nrun)
plt.xlabel('time')
plt.ylabel('<m>')
plt.title('average matization over time')
plt.show()

plt.plot(t_backup/nrun, (avm_square**2/nrun-(avm/nrun)**2)/np.sqrt(nrun))
plt.xlabel('time')
plt.ylabel('<m^2> - <m>^2')
plt.title('sigma_m')
plt.show()