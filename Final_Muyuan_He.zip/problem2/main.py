import numpy as np
import math as m
import cmath
from math import e
import matplotlib.pyplot as plt


# Initialize parameters (grid spacing, time step, etc.)
i_imag = 1j
N = 3000
L = 1000
h = L / (N - 1)  #dx
x = np.arange(N) * h - L/2  # grid points
#print(dx)
h_bar = 1
mass = 1
tau = 1e-2 # time step
u = 0.5
#u = 2.0 # uncomment this line to change u to 2.0


ham = np.zeros((N, N))
coeff = -h_bar ** 2 / (2 * mass * h ** 2)
for i in np.arange(1, N - 1):
    if i == N/2:
        ham[i, i - 1] = coeff
        ham[i, i] = -2 * coeff + u/h # normalize
        ham[i, i + 1] = coeff
    else:
        ham[i, i - 1] = coeff
        ham[i, i] = -2 * coeff
        ham[i, i + 1] = coeff

# First and last rows for periodic boundary conditions
ham[0, N-1] , ham[0, 0] , ham[0, 1] = coeff, -2*coeff, coeff
ham[N-1, N-2] , ham[N-1, N-1] , ham[N-1, 0] = coeff, -2*coeff, coeff

dCN = np.dot(np.linalg.inv(np.identity(N) + .5 * i_imag * tau / h_bar * ham),
             (np.identity(N) - .5 * i_imag * tau / h_bar * ham))

# Initialize the wavefunction
x0 = -L/4
sigma0 = 20
Norm_psi = 1/(m.sqrt(sigma0 * m.sqrt(np.pi)))


psi = np.empty(N, dtype=np.complex)
for i in np.arange(N):
    psi[i] = Norm_psi * np.exp(i_imag * x[i]) * np.exp(-(x[i] - x0) ** 2 / (2 * sigma0 ** 2))

# initiate wave
plt.plot(x, np.real(psi), '-', x, np.imag(psi), '--')
plt.xlabel('x')
plt.ylabel(r'$\psi(x)$')
plt.legend(('Real ', 'Imag '))
plt.title('\u03C8(x)_init')
plt.show()

# start loop
max_iter = int(L / tau)
plot_iter = max_iter / 8  # Produce 8+1 curves
p_plot = np.empty((N, max_iter + 1))  # Note that P(x,t) is real
p_plot[:, 0] = np.absolute(psi[:]) ** 2  # Record initial condition
iplot = 0
axisV = [-L / 2, L / 2, 0, max(p_plot[:, 0])]  # Fix axis min and max

for iter in range(max_iter):

    psi = np.dot(dCN, psi)

    if (iter + 1) % plot_iter < 1:
        iplot += 1
        p_plot[:, iplot] = np.absolute(psi[:]) ** 2
        plt.plot(x, p_plot[:, iplot])  # Display snap-shot of P(x)
        plt.xlabel('x')
        plt.ylabel('P(x,t)')
        plt.title('Finished %d of %d iterations' % (iter, max_iter))
        plt.axis(axisV)
        plt.show()

#  Plot probability versus position at various times
pFinal = np.empty(N)
pFinal = np.absolute(psi[:]) ** 2
for i in range(iplot + 1):
    plt.plot(x, p_plot[:, i])
plt.xlabel('x')
plt.ylabel('P(x,t)')
plt.title('Probability density at various times')
plt.show()























# N = 200 # grid #
# L = 1000
# i_imag = 1j
# dx = L/(N-1) # h in the book
# x = np.arange(N) * dx - L/2
# #print("Here is x: ", x)
# dt = 1e-2
#
# # create H hamiltonian operator matrix
# H =np.zeros((N, N))
# coeff = -1/(2*dx**2) # -h_bar^2/2mh^2
# for i in np.arange(1, N-1):
#     H[i, i-1] = coeff
#     H[i, i] = -2*coeff
#     H[i, i+1] = coeff
# H[0, N-1] , H[0, 0] , H[0, 1] = coeff, -2*coeff, coeff
# H[N-1, N-2] , H[N-1, N-1] , H[N-1, 0] = coeff, -2*coeff, coeff
#
# dCN = np.dot(np.linalg.inv(np.identity(N) + .5*1*H), (np.identity(N) - .5*1*H))
#
# # Initialize the wavefunction


# x0 = -L/4
# sigma_0 = 20
# norm_psi = 1/m.sqrt(sigma_0*m.sqrt(m.pi))
# psi = np.zeros(N, dtype=np.complex)
# for i in np.arange(N):
#     #psi[i] = norm_psi * m.exp(1j * x[i] - (x[i]-x0)**2/(2*sigma_0)**2)
#     #print(norm_psi * e**(1j * x[i] - (x[i]-x0)**2/(2*sigma_0)**2))
#     psi[i] = norm_psi * e**(1j * x[i] - (x[i] - x0) ** 2 / (2 * sigma_0) ** 2)
# #psi = norm_psi * m.exp(1j * np.transpose(x) - (np.transpose(x)-x0)**2/(2*sigma_0)**2)
#
#
# #print("Real part: ", psi_list.real)
# #print("Imaginary part: ", psi_list.imag)
# plt.figure("1")
# plt.plot(psi.real, "black")
# plt.xlabel("x")
# plt.ylabel("\u03C8(x)") # psi(x)
# plt.plot(psi.imag, "blue")
# plt.show()
#
# # Initialize loop and plot
# max_iter = L/dt
# plot_iter = max_iter/10
# p_plot = np.zeros(N, dtype=np.complex) # init condition recorder, store psi^2
# p_plot[0] = np.dot(psi, np.conj(psi))
# #print(p_plot)
# iplot = 1
# plt.figure(2)
# axisV = []
# axisV.append([-L/2, L/2, 0, max(p_plot)]) #fix axis min and max
# #print(axisV)
# for i in np.arange(max_iter):
#     psi = dCN * psi # compute new psi using Crank-Nicolson scheme
#     #print(psi)
#     #periodically record values for plotting
#     if i % iplot < 1: # reminder
#         iplot += 1
#         p_plot[i] = np.dot(psi, np.conj(psi))
#         # Now real-time plot
#         plt.plot(x, p_plot)
#         plt.xlabel("x")
#         plt.ylabel("P(x, t)")
#         plt.pause(0.05)
#
#
