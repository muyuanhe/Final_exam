import numpy as np
import math as m
import matplotlib.pyplot as plt


N= 200
L = 10
dx= L/(N-1)
dt= 1e-3
D = 1

def FP_eqn(T):
    # create H hamiltonian operator matrix
    H =np.zeros((N, N))
    for i in np.arange(1, N-1):
        H[i, i-1] = D*dt/dx/dx
        H[i, i] = -2*D*dt/dx/dx + dt/dx
        H[i, i+1] = D*dt/dx/dx - dt/dx

    H[1, 0] = D*dt/dx/dx
    H[N - 2, N - 1] = D*dt/dx/dx - dt/dx

    H[0, 0] = 1
    H[0, 1] = -1 # this pair cancel out s.t. (p1-p2)/dt == 0, at the boundary, equals 0

    H[N-1, N-2] = 1
    H[N-1, N-1] = -1 # this pair needs to cancel for the same reason

    #print(H)
    dCN = np.dot(np.linalg.inv(np.identity(N) - H/2),(np.identity(N) + H/2))
    print(dCN)

    inc = np.linspace(0, m.pi, N)
    #print(inc)
    #p = np.zeros(N, dtype=float) # define
    #p[int(N/2)] = N
    p = np.cos(inc) # such that at both ends, first derivative are 0 since d/dx(cos(x)) == 1 at x = 0, pi
    print(p)

    max_iter = int(T/dt)

    for i in np.arange(max_iter):
        p = np.dot(dCN, p)
        #print(p)
    return p


r = FP_eqn(10) # Here choose a Time that is large enough
x = np.asarray(range(N)) * dx
#print(r)
plt.plot(x, r)
plt.show()

